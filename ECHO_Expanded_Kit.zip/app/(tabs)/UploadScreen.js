import React, { useState } from 'react';
import { View, Button, StyleSheet, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { addDoc, collection } from 'firebase/firestore';
import { storage, db } from '../../firebase/config';
import { Video as ExpoVideo } from 'expo-av';

export default function UploadScreen() {
  const [video, setVideo] = useState(null);

  const pickVideo = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Videos,
      allowsEditing: false,
    });

    if (!result.canceled) {
      setVideo(result.assets[0].uri);
    }
  };

  const uploadVideo = async () => {
    if (!video) return;

    try {
      const response = await fetch(video);
      const blob = await response.blob();
      const filename = video.substring(video.lastIndexOf('/') + 1);
      const videoRef = ref(storage, `videos/${filename}`);
      await uploadBytes(videoRef, blob);
      const downloadURL = await getDownloadURL(videoRef);
      await addDoc(collection(db, 'uploads'), {
        type: 'video',
        filename,
        url: downloadURL,
        timestamp: new Date(),
      });
      Alert.alert('Success', 'Video uploaded:\n' + downloadURL);
    } catch (error) {
      Alert.alert('Error', error.message);
    }
  };

  return (
    <View style={styles.container}>
      <Button title="Pick a Video" onPress={pickVideo} />
      {video && (
        <ExpoVideo
          source={{ uri: video }}
          style={styles.video}
          useNativeControls
          resizeMode="contain"
        />
      )}
      <Button title="Upload Video" onPress={uploadVideo} disabled={!video} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 },
  video: { width: 320, height: 180, marginVertical: 20 },
});
