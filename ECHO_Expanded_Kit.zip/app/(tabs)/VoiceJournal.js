import React, { useState, useEffect } from 'react';
import { View, Button, Text, StyleSheet, Alert } from 'react-native';
import { Audio } from 'expo-av';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { addDoc, collection } from 'firebase/firestore';
import { storage, db } from '../../firebase/config';

export default function VoiceJournal() {
  const [recording, setRecording] = useState(null);
  const [uri, setUri] = useState(null);

  useEffect(() => {
    Audio.requestPermissionsAsync();
  }, []);

  const startRecording = async () => {
    try {
      await Audio.setAudioModeAsync({ allowsRecordingIOS: true, playsInSilentModeIOS: true });
      const { recording } = await Audio.Recording.createAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY);
      setRecording(recording);
    } catch (err) {
      console.error('Failed to start recording', err);
    }
  };

  const stopRecording = async () => {
    try {
      await recording.stopAndUnloadAsync();
      const uri = recording.getURI();
      setUri(uri);
      setRecording(null);
    } catch (err) {
      console.error('Failed to stop recording', err);
    }
  };

  const uploadAudio = async () => {
    if (!uri) return;

    try {
      const response = await fetch(uri);
      const blob = await response.blob();
      const filename = uri.substring(uri.lastIndexOf('/') + 1);
      const audioRef = ref(storage, `audio/${filename}`);
      await uploadBytes(audioRef, blob);
      const downloadURL = await getDownloadURL(audioRef);
      await addDoc(collection(db, 'uploads'), {
        type: 'audio',
        filename,
        url: downloadURL,
        timestamp: new Date(),
      });
      Alert.alert('Uploaded', 'Audio journal uploaded:\n' + downloadURL);
    } catch (error) {
      Alert.alert('Error uploading', error.message);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Voice Journal</Text>
      <Button title={recording ? 'Stop Recording' : 'Start Recording'} onPress={recording ? stopRecording : startRecording} />
      {uri && <Button title="Upload Recording" onPress={uploadAudio} />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 20, marginBottom: 20 },
});
