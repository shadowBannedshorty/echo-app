import { Tabs } from 'expo-router';

export default function TabLayout() {
  return (
    <Tabs>
      <Tabs.Screen name="HomeScreen" options={{ title: 'Home' }} />
      <Tabs.Screen name="UploadScreen" options={{ title: 'Upload' }} />
      <Tabs.Screen name="VoiceJournal" options={{ title: 'Voice Journal' }} />
      <Tabs.Screen name="StoryBoard" options={{ title: 'StoryBoard' }} />
    </Tabs>
  );
}
