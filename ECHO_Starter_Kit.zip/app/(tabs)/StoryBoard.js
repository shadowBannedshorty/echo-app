import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function StoryBoard() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Your ECHO Storyboard</Text>
      <Text style={styles.placeholder}>Coming soon: a gallery of your uploads and memories.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' },
  title: { fontSize: 22, fontWeight: 'bold' },
  placeholder: { fontSize: 16, marginTop: 10, color: '#888' },
});
